import math as math
import numpy as np
lista =[]
with open("australian.dat","r") as file:
    lista = [list(map(lambda e: float(e),line.split())) for line in file]
def MetrykaEuklidesowa(listaA, listaB):

    dl = len(listaA) - 1
    tmp = 0
    for id in range(dl):
        zm1 = listaA[id]
        zm2 = listaB[id]
        c = zm1 - zm2
        wynik = c ** 2
        tmp += wynik

    result = math.sqrt(tmp)

    return result
def MetrykaEuklidesowa2(listaA,listaB):
    v1=np.array(lista)
    v2=np.array(lista2)
    wynik = v1- v2
    return m.sqrt(np.dot(wynik,wynik))

def Nazwa(lista, index_decyzyjna, sasiad):
    slownik = dict()
    for x in range(0, len(lista)):
        KlasaDecyzyjna = lista[x][index_decyzyjna]
        if KlasaDecyzyjna in slownik.keys():
            slownik[KlasaDecyzyjna].append(MetrykaEuklidesowa(sasiad, lista[x]))
        else:
            slownik[KlasaDecyzyjna] = [MetrykaEuklidesowa(sasiad, lista[x])]
    return slownik

def Nazwa_lista(lista, index_decyzyjna, sasiad):
    lista = []
    for x in range(0,len(lista)):
        KlasaDecyzyjna = lista[x][index_decyzyjna]
        lista.append((KlasaDecyzyjna,MetrykaEuklidesowa2(nowa_osoba, lista[x])))    
    return lista



grupowanie = Nazwa(lista, -1, [1,1,1,1,1,1,1,1,1,1,1,1,1,1])
grupowanie[0].sort()
grupowanie[1].sort()
print(sum(grupowanie[0][:-5]))
print(sum(grupowanie[1][:5]))


