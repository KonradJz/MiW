import math as m
import numpy as np

matrix = []
with open("../Lab_03/australian.dat","r") as file:
    matrix = [list(map(lambda a: float(a),line.split())) for line in file]


def Srednia(lista):
    suma = 0.0
    for x in lista:
        suma+=x
    return float(suma/(float(len(lista))))

def Wariancja(lista):
    srednia = Srednia(lista)
    suma= 0.0
    for x in lista:
        suma+= (x - srednia)**2
    return float(suma/(float(len(lista))))

def OdchylenieStandardowe(lista):
    return m.sqrt(Wariancja(lista))


print("============ v 1.0 =================")

matrix_2 = [x[:14] for x in matrix] #matrix without decission
print(Srednia(matrix_2[0]))
print(Wariancja(matrix_2[0]))
print(OdchylenieStandardowe(matrix_2[0]))


def SredniaMacierz(lista):
    ones = np.ones((len(lista),1))
    return float(1/len(lista))*np.dot(np.array(lista),ones)[0]

def WariancjaMacierz(lista):
    srednia = SredniaMacierz(lista)
    ones = np.ones((1,len(lista)))*srednia
    minus = np.array(lista) - ones
    return float(1/len(lista))*np.dot(minus[0],minus[0].T)

def OdchylenieStandardowe_matrix(lista):
    return m.sqrt(WariancjaMacierz(lista))


print("============ v 2.0 =================")
print(SredniaMacierz(matrix_2[0]))
print(WariancjaMacierz(matrix_2[0]))
print(OdchylenieStandardowe_matrix(matrix_2[0]))