print("Ala {0} {1}".format('ma', 'kota.'))

print("Podaj imie")
#imie = input()
#print("Cześć {}".format(imie))
#print(imie[::])

liczba = '123'
liczba2 = 123
liczba3 = 12.3

print("String: {0}, Int: {1}, Float: {2}".format(liczba, liczba2, liczba3))

zdanie = ['Ala','ma','chyba','kota']
print(" ".join(zdanie))

zdanie2 = "Ala ma chyb akota"
print(zdanie2.split())

prawdziwezdanie = "Metody Inżynierii Wiedzy Są Najlepsze"
print(prawdziwezdanie,  len(prawdziwezdanie))

print(prawdziwezdanie.replace("ą", "a"))
print(prawdziwezdanie.replace(" ", ""), len(prawdziwezdanie.replace(" ", "")))

x = "Test"
y = 10
z = (x,y)
print(z)
print(type(z))

liczby = (1,2,3,4,5)
litery = ("a", "b", "c", "d", "e")
merged = liczby + litery
print(merged)
print(merged[3:4])

print(liczby.index(2))

lista1 = [1,2,3,4]
lista2 = [2,3,4,5]
lista1.extend(lista2)
print(lista1)

kraje = {
    "Polska" : "Warszawa",
    "Niemcy" : "Berlin",
    "Rosja" : "Moskwa",
    "Czechy" : "Praga",
    "Litwa" : "Wilno",
    "Białoruś" : "Mińsk",
    "Słowacja" : "Bratysława",
    "Ukraina" : "Kijów"
}

print(sorted(kraje))


